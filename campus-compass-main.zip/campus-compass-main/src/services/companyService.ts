import { Company } from "@/types/company";

// Abstract data access layer — will be wired to Supabase later
// All functions return promises to support async data fetching

let _companies: Company[] = [];

export const companyService = {
  async getAll(): Promise<Company[]> {
    // TODO: Replace with Supabase query
    return _companies;
  },

  async getById(id: string): Promise<Company | undefined> {
    const companies = await this.getAll();
    return companies.find((c) => c.id === id || c.short_name === id);
  },

  async getByCategory(category: string): Promise<Company[]> {
    const companies = await this.getAll();
    return companies.filter((c) =>
      c.category?.toLowerCase().includes(category.toLowerCase())
    );
  },

  async search(query: string): Promise<Company[]> {
    const companies = await this.getAll();
    const q = query.toLowerCase();
    return companies.filter(
      (c) =>
        c.name?.toLowerCase().includes(q) ||
        c.short_name?.toLowerCase().includes(q) ||
        c.focus_sectors?.toLowerCase().includes(q) ||
        c.tech_stack?.toLowerCase().includes(q) ||
        c.category?.toLowerCase().includes(q)
    );
  },

  async getCategories(): Promise<string[]> {
    const companies = await this.getAll();
    const cats = new Set(companies.map((c) => c.category).filter(Boolean) as string[]);
    return Array.from(cats);
  },

  async getStats() {
    const companies = await this.getAll();
    return {
      total: companies.length,
      categories: new Set(companies.map((c) => c.category).filter(Boolean)).size,
      profitable: companies.filter((c) =>
        c.profitability_status?.toLowerCase().includes("profitable")
      ).length,
      remote: companies.filter((c) =>
        c.remote_policy_details?.toLowerCase().includes("remote")
      ).length,
    };
  },
};
