import { useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { useCompany } from "@/hooks/useCompanies";
import CompanyDetail from "@/components/company/CompanyDetail";
import AppLayout from "@/components/layout/AppLayout";

export default function CompanyDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { data: company, isLoading } = useCompany(decodeURIComponent(id || ""));

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto px-4 py-4">
        <Link
          to="/explore"
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft size={14} />
          Back to companies
        </Link>

        {isLoading && (
          <div className="text-center py-16">
            <p className="text-sm text-muted-foreground">Loading company data...</p>
          </div>
        )}

        {!isLoading && !company && (
          <div className="text-center py-16 surface-card">
            <p className="text-sm text-muted-foreground">Company not found.</p>
          </div>
        )}

        {company && <CompanyDetail company={company} />}
      </div>
    </AppLayout>
  );
}
