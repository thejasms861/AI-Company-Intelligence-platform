import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Search,
  Building2,
  Users,
  TrendingUp,
  Briefcase,
  BarChart3,
  Globe,
  Zap,
  ArrowRight,
} from "lucide-react";
import { useCompanies, useCompanyStats } from "@/hooks/useCompanies";
import CompanyCard from "@/components/company/CompanyCard";
import AppLayout from "@/components/layout/AppLayout";

const categoryTiles = [
  { label: "Tech Giants", icon: Zap, color: "text-primary" },
  { label: "Product Companies", icon: Briefcase, color: "text-primary" },
  { label: "Service Companies", icon: Users, color: "text-primary" },
  { label: "Startups / Scale-ups", icon: TrendingUp, color: "text-primary" },
];

export default function HomePage() {
  const { data: companies = [] } = useCompanies();
  const { data: stats } = useCompanyStats();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCompanies = searchQuery
    ? companies.filter(
        (c) =>
          c.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.short_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.focus_sectors?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.tech_stack?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <AppLayout>
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Hero */}
        <div className="text-center mb-10">
          <h1 className="text-3xl sm:text-4xl font-semibold text-foreground mb-3">
            PES Placement Intelligence
          </h1>
          <p className="text-muted-foreground text-base max-w-xl mx-auto">
            Data-driven insights for campus placement decisions. Analyze companies across 163 structured parameters.
          </p>
        </div>

        {/* Search */}
        <div className="max-w-2xl mx-auto mb-10">
          <div className="relative">
            <Search
              size={20}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <input
              type="text"
              placeholder="Search companies, sectors, tech stack..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-12 pl-11 pr-4 rounded-full border bg-card text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-shadow"
              style={{ boxShadow: "var(--shadow-md)" }}
            />
          </div>

          {/* Search results */}
          {searchQuery && (
            <div className="mt-3 space-y-2">
              {filteredCompanies.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No companies found. Connect your database to search.
                </p>
              ) : (
                <div className="grid gap-3 sm:grid-cols-2">
                  {filteredCompanies.slice(0, 6).map((c, i) => (
                    <CompanyCard key={i} company={c} />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-10">
          {[
            { label: "Total Companies", value: stats?.total ?? 0, icon: Building2 },
            { label: "Categories", value: stats?.categories ?? 0, icon: BarChart3 },
            { label: "Profitable", value: stats?.profitable ?? 0, icon: TrendingUp },
            { label: "Remote-friendly", value: stats?.remote ?? 0, icon: Globe },
          ].map((stat) => (
            <div key={stat.label} className="surface-card p-4 text-center">
              <stat.icon size={20} className="mx-auto text-primary mb-2" />
              <div className="metric-value">{stat.value}</div>
              <div className="metric-label">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Category Tiles */}
        <h2 className="section-header mb-4">
          <BarChart3 size={18} className="text-primary" />
          Explore by Category
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-10">
          {categoryTiles.map((cat) => (
            <Link
              key={cat.label}
              to={`/categories?q=${encodeURIComponent(cat.label)}`}
              className="surface-card p-5 text-center hover:shadow-md transition-shadow group"
            >
              <cat.icon
                size={28}
                className={`mx-auto mb-2 ${cat.color} group-hover:scale-110 transition-transform`}
              />
              <span className="text-sm font-medium text-foreground">{cat.label}</span>
            </Link>
          ))}
        </div>

        {/* Insight Cards */}
        <h2 className="section-header mb-4">
          <Zap size={18} className="text-primary" />
          Quick Insights
        </h2>
        <div className="grid sm:grid-cols-3 gap-3 mb-10">
          {[
            {
              title: "Hiring Velocity",
              desc: "Analyze hiring trends across companies",
              to: "/analytics",
            },
            {
              title: "Profitability Mix",
              desc: "Profitable vs growth-stage companies",
              to: "/analytics",
            },
            {
              title: "Work Model Distribution",
              desc: "Remote, hybrid and on-site breakdown",
              to: "/analytics",
            },
          ].map((insight) => (
            <Link
              key={insight.title}
              to={insight.to}
              className="surface-card p-4 hover:shadow-md transition-shadow group"
            >
              <h3 className="text-sm font-semibold text-foreground mb-1">{insight.title}</h3>
              <p className="text-xs text-muted-foreground mb-2">{insight.desc}</p>
              <span className="text-xs text-primary font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
                View <ArrowRight size={12} />
              </span>
            </Link>
          ))}
        </div>

        {/* Recent Companies */}
        {companies.length > 0 && (
          <>
            <div className="flex items-center justify-between mb-4">
              <h2 className="section-header">
                <Building2 size={18} className="text-primary" />
                Companies
              </h2>
              <Link to="/explore" className="text-xs text-primary font-medium hover:underline">
                View all →
              </Link>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {companies.slice(0, 6).map((c, i) => (
                <CompanyCard key={i} company={c} />
              ))}
            </div>
          </>
        )}

        {/* Empty State */}
        {companies.length === 0 && !searchQuery && (
          <div className="text-center py-12 surface-card">
            <Building2 size={40} className="mx-auto text-muted-foreground mb-3" />
            <h3 className="text-lg font-medium text-foreground mb-1">No companies yet</h3>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Connect your database to start exploring placement intelligence data across 163 structured parameters.
            </p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
