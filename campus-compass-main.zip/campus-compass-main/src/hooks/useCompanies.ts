import { useQuery } from "@tanstack/react-query";
import { companyService } from "@/services/companyService";

export function useCompanies() {
  return useQuery({
    queryKey: ["companies"],
    queryFn: () => companyService.getAll(),
  });
}

export function useCompany(id: string) {
  return useQuery({
    queryKey: ["company", id],
    queryFn: () => companyService.getById(id),
    enabled: !!id,
  });
}

export function useCompanySearch(query: string) {
  return useQuery({
    queryKey: ["companies", "search", query],
    queryFn: () => companyService.search(query),
    enabled: query.length > 0,
  });
}

export function useCompanyStats() {
  return useQuery({
    queryKey: ["company-stats"],
    queryFn: () => companyService.getStats(),
  });
}

export function useCategories() {
  return useQuery({
    queryKey: ["categories"],
    queryFn: () => companyService.getCategories(),
  });
}
