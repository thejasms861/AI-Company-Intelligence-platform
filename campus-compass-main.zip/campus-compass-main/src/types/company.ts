export interface Company {
  id?: string;
  name: string;
  short_name: string;
  logo_url: string;
  category: string;
  incorporation_year: string;
  overview_text: string;
  nature_of_company: string;
  headquarters_address: string;
  operating_countries: string;
  office_count: string;
  office_locations: string;
  employee_size: string;
  hiring_velocity: string;
  employee_turnover: string;
  avg_retention_tenure: string;
  pain_points_addressed: string;
  focus_sectors: string;
  offerings_description: string;
  top_customers: string;
  core_value_proposition: string;
  vision: string;
  mission: string;
  values: string;
  unique_differentiators: string;
  competitive_advantages: string;
  weaknesses_gaps: string;
  key_challenges_needs: string;
  key_competitors: string;
  technology_partners: string;
  interesting_facts: string;
  recent_news: string;
  website_url: string;
  website_quality: string;
  website_rating: string;
  website_traffic_rank: string;
  social_media_followers: string;
  glassdoor_rating: string;
  indeed_rating: string;
  google_rating: string;
  linkedin_url: string;
  twitter_handle: string;
  facebook_url: string;
  instagram_url: string;
  ceo_name: string;
  ceo_linkedin_url: string;
  key_leaders: string;
  warm_intro_pathways: string;
  decision_maker_access: string;
  primary_contact_email: string;
  primary_phone_number: string;
  contact_person_name: string;
  contact_person_title: string;
  contact_person_email: string;
  contact_person_phone: string;
  awards_recognitions: string;
  brand_sentiment_score: string;
  event_participation: string;
  regulatory_status: string;
  legal_issues: string;
  annual_revenue: string;
  annual_profit: string;
  revenue_mix: string;
  valuation: string;
  yoy_growth_rate: string;
  profitability_status: string;
  market_share_percentage: string;
  key_investors: string;
  recent_funding_rounds: string;
  total_capital_raised: string;
  esg_ratings: string;
  sales_motion: string;
  customer_acquisition_cost: string;
  customer_lifetime_value: string;
  cac_ltv_ratio: string;
  churn_rate: string;
  nps: string;
  customer_concentration_risk: string;
  burn_rate: string;
  runway_months: string;
  burn_multiplier: string;
  intellectual_property: string;
  r_and_d_investment: string;
  ai_ml_adoption_level: string;
  tech_stack: string;
  cybersecurity_posture: string;
  supply_chain_dependencies: string;
  geopolitical_risks: string;
  macro_risks: string;
  diversity_metrics: string;
  remote_policy_details: string;
  training_spend: string;
  partnership_ecosystem: string;
  exit_strategy: string;
  carbon_footprint: string;
  ethical_standards: string;
  benchmark_vs_peers: string;
  future_projections: string;
  strategic_priorities: string;
  industry_associations: string;
  case_studies: string;
  go_to_market_strategy: string;
  innovation_roadmap: string;
  product_pipeline: string;
  board_members: string;
  marketing_video_url: string;
  customer_testimonials: string;
  tech_adoption_rating: string;
  tam: string;
  sam: string;
  som: string;
  work_culture_summary: string;
  manager_quality: string;
  psychological_safety: string;
  feedback_culture: string;
  diversity_inclusion_score: string;
  typical_hours: string;
  overtime_expectations: string;
  weekend_work: string;
  flexibility_level: string;
  leave_policy: string;
  burnout_risk: string;
  location_centrality: string;
  public_transport_access: string;
  cab_policy: string;
  airport_commute_time: string;
  office_zone_type: string;
  area_safety: string;
  safety_policies: string;
  infrastructure_safety: string;
  emergency_preparedness: string;
  health_support: string;
  onboarding_quality: string;
  learning_culture: string;
  exposure_quality: string;
  mentorship_availability: string;
  internal_mobility: string;
  promotion_clarity: string;
  tools_access: string;
  role_clarity: string;
  early_ownership: string;
  work_impact: string;
  execution_thinking_balance: string;
  automation_level: string;
  cross_functional_exposure: string;
  company_maturity: string;
  brand_value: string;
  client_quality: string;
  layoff_history: string;
  fixed_vs_variable_pay: string;
  bonus_predictability: string;
  esops_incentives: string;
  family_health_insurance: string;
  relocation_support: string;
  lifestyle_benefits: string;
  exit_opportunities: string;
  skill_relevance: string;
  external_recognition: string;
  network_strength: string;
  global_exposure: string;
  mission_clarity: string;
  sustainability_csr: string;
  crisis_behavior: string;
  history_timeline: string;
}

export type CompanyField = keyof Company;

export interface CompanySection {
  title: string;
  icon: string;
  fields: { key: CompanyField; label: string }[];
}

export const companySections: CompanySection[] = [
  {
    title: "Company Overview",
    icon: "Building2",
    fields: [
      { key: "name", label: "Company Name" },
      { key: "short_name", label: "Short Name" },
      { key: "category", label: "Category" },
      { key: "incorporation_year", label: "Year of Incorporation" },
      { key: "nature_of_company", label: "Nature of Company" },
      { key: "headquarters_address", label: "Headquarters" },
      { key: "operating_countries", label: "Operating Countries" },
      { key: "office_count", label: "Number of Offices" },
      { key: "office_locations", label: "Office Locations" },
      { key: "employee_size", label: "Employee Size" },
      { key: "overview_text", label: "Overview" },
      { key: "history_timeline", label: "History" },
      { key: "recent_news", label: "Recent News" },
    ],
  },
  {
    title: "Business & Market",
    icon: "TrendingUp",
    fields: [
      { key: "pain_points_addressed", label: "Pain Points Addressed" },
      { key: "focus_sectors", label: "Focus Sectors" },
      { key: "offerings_description", label: "Offerings" },
      { key: "top_customers", label: "Top Customers" },
      { key: "core_value_proposition", label: "Core Value Proposition" },
      { key: "unique_differentiators", label: "Unique Differentiators" },
      { key: "competitive_advantages", label: "Competitive Advantages" },
      { key: "weaknesses_gaps", label: "Weaknesses / Gaps" },
      { key: "key_challenges_needs", label: "Key Challenges" },
      { key: "key_competitors", label: "Key Competitors" },
      { key: "tam", label: "TAM" },
      { key: "sam", label: "SAM" },
      { key: "som", label: "SOM" },
      { key: "market_share_percentage", label: "Market Share" },
      { key: "go_to_market_strategy", label: "Go-to-Market Strategy" },
      { key: "strategic_priorities", label: "Strategic Priorities" },
      { key: "future_projections", label: "Future Projections" },
    ],
  },
  {
    title: "Culture, People & Work",
    icon: "Users",
    fields: [
      { key: "work_culture_summary", label: "Work Culture" },
      { key: "hiring_velocity", label: "Hiring Velocity" },
      { key: "employee_turnover", label: "Employee Turnover" },
      { key: "avg_retention_tenure", label: "Avg. Retention Tenure" },
      { key: "manager_quality", label: "Manager Quality" },
      { key: "psychological_safety", label: "Psychological Safety" },
      { key: "feedback_culture", label: "Feedback Culture" },
      { key: "diversity_metrics", label: "Diversity Metrics" },
      { key: "diversity_inclusion_score", label: "D&I Score" },
      { key: "ethical_standards", label: "Ethical Standards" },
      { key: "layoff_history", label: "Layoff History" },
      { key: "burnout_risk", label: "Burnout Risk" },
      { key: "mission_clarity", label: "Mission Clarity" },
    ],
  },
  {
    title: "Learning, Growth & Career Signal",
    icon: "GraduationCap",
    fields: [
      { key: "training_spend", label: "Training Spend" },
      { key: "onboarding_quality", label: "Onboarding Quality" },
      { key: "learning_culture", label: "Learning Culture" },
      { key: "exposure_quality", label: "Exposure Quality" },
      { key: "mentorship_availability", label: "Mentorship" },
      { key: "internal_mobility", label: "Internal Mobility" },
      { key: "promotion_clarity", label: "Promotion Clarity" },
      { key: "tools_access", label: "Tools & Tech Access" },
      { key: "role_clarity", label: "Role Clarity" },
      { key: "early_ownership", label: "Early Ownership" },
      { key: "work_impact", label: "Work Impact" },
      { key: "execution_thinking_balance", label: "Execution vs Thinking" },
      { key: "automation_level", label: "Automation Level" },
      { key: "cross_functional_exposure", label: "Cross-functional Exposure" },
      { key: "exit_opportunities", label: "Exit Opportunities" },
      { key: "skill_relevance", label: "Skill Relevance" },
      { key: "network_strength", label: "Network Strength" },
      { key: "global_exposure", label: "Global Exposure" },
      { key: "external_recognition", label: "External Recognition" },
    ],
  },
  {
    title: "Compensation & Lifestyle",
    icon: "Wallet",
    fields: [
      { key: "fixed_vs_variable_pay", label: "Fixed vs Variable Pay" },
      { key: "bonus_predictability", label: "Bonus Predictability" },
      { key: "esops_incentives", label: "ESOPs / Incentives" },
      { key: "family_health_insurance", label: "Family Health Insurance" },
      { key: "relocation_support", label: "Relocation Support" },
      { key: "lifestyle_benefits", label: "Lifestyle Benefits" },
      { key: "leave_policy", label: "Leave Policy" },
      { key: "health_support", label: "Health Support" },
    ],
  },
  {
    title: "Work Logistics & Safety",
    icon: "Shield",
    fields: [
      { key: "remote_policy_details", label: "Remote Policy" },
      { key: "typical_hours", label: "Typical Hours" },
      { key: "overtime_expectations", label: "Overtime Expectations" },
      { key: "weekend_work", label: "Weekend Work" },
      { key: "flexibility_level", label: "Flexibility Level" },
      { key: "location_centrality", label: "Location Centrality" },
      { key: "public_transport_access", label: "Public Transport" },
      { key: "cab_policy", label: "Cab Policy" },
      { key: "airport_commute_time", label: "Airport Commute" },
      { key: "office_zone_type", label: "Office Zone Type" },
      { key: "area_safety", label: "Area Safety" },
      { key: "safety_policies", label: "Safety Policies" },
      { key: "infrastructure_safety", label: "Infrastructure Safety" },
      { key: "emergency_preparedness", label: "Emergency Preparedness" },
    ],
  },
  {
    title: "Financials, Risk & Stability",
    icon: "BarChart3",
    fields: [
      { key: "annual_revenue", label: "Annual Revenue" },
      { key: "annual_profit", label: "Annual Profit" },
      { key: "revenue_mix", label: "Revenue Mix" },
      { key: "valuation", label: "Valuation" },
      { key: "yoy_growth_rate", label: "YoY Growth Rate" },
      { key: "profitability_status", label: "Profitability Status" },
      { key: "key_investors", label: "Key Investors" },
      { key: "recent_funding_rounds", label: "Funding Rounds" },
      { key: "total_capital_raised", label: "Total Capital Raised" },
      { key: "burn_rate", label: "Burn Rate" },
      { key: "runway_months", label: "Runway" },
      { key: "burn_multiplier", label: "Burn Multiplier" },
      { key: "esg_ratings", label: "ESG Ratings" },
      { key: "regulatory_status", label: "Regulatory Status" },
      { key: "legal_issues", label: "Legal Issues" },
      { key: "supply_chain_dependencies", label: "Supply Chain" },
      { key: "geopolitical_risks", label: "Geopolitical Risks" },
      { key: "macro_risks", label: "Macro Risks" },
    ],
  },
  {
    title: "Technology & Innovation",
    icon: "Cpu",
    fields: [
      { key: "tech_stack", label: "Tech Stack" },
      { key: "technology_partners", label: "Technology Partners" },
      { key: "intellectual_property", label: "Intellectual Property" },
      { key: "r_and_d_investment", label: "R&D Investment" },
      { key: "ai_ml_adoption_level", label: "AI/ML Adoption" },
      { key: "cybersecurity_posture", label: "Cybersecurity Posture" },
      { key: "innovation_roadmap", label: "Innovation Roadmap" },
      { key: "product_pipeline", label: "Product Pipeline" },
      { key: "tech_adoption_rating", label: "Tech Adoption Rating" },
      { key: "partnership_ecosystem", label: "Partnership Ecosystem" },
    ],
  },
  {
    title: "Leadership & Contacts",
    icon: "UserCircle",
    fields: [
      { key: "ceo_name", label: "CEO" },
      { key: "ceo_linkedin_url", label: "CEO LinkedIn" },
      { key: "key_leaders", label: "Key Leaders" },
      { key: "board_members", label: "Board Members" },
      { key: "warm_intro_pathways", label: "Warm Intro Pathways" },
      { key: "decision_maker_access", label: "Decision Maker Access" },
      { key: "primary_contact_email", label: "Contact Email" },
      { key: "primary_phone_number", label: "Phone Number" },
      { key: "contact_person_name", label: "Contact Person" },
      { key: "contact_person_title", label: "Contact Title" },
      { key: "contact_person_email", label: "Contact Email" },
      { key: "contact_person_phone", label: "Contact Phone" },
    ],
  },
  {
    title: "Brand & Digital Presence",
    icon: "Globe",
    fields: [
      { key: "website_url", label: "Website" },
      { key: "website_quality", label: "Website Quality" },
      { key: "website_rating", label: "Website Rating" },
      { key: "website_traffic_rank", label: "Traffic Rank" },
      { key: "social_media_followers", label: "Social Media Followers" },
      { key: "glassdoor_rating", label: "Glassdoor Rating" },
      { key: "indeed_rating", label: "Indeed Rating" },
      { key: "google_rating", label: "Google Rating" },
      { key: "linkedin_url", label: "LinkedIn" },
      { key: "twitter_handle", label: "Twitter" },
      { key: "facebook_url", label: "Facebook" },
      { key: "instagram_url", label: "Instagram" },
      { key: "marketing_video_url", label: "Marketing Video" },
      { key: "customer_testimonials", label: "Testimonials" },
      { key: "awards_recognitions", label: "Awards" },
      { key: "brand_sentiment_score", label: "Brand Sentiment" },
      { key: "event_participation", label: "Event Participation" },
    ],
  },
];
