import { Company } from "@/types/company";
import { Building2, Users, TrendingUp, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

interface CompanyCardProps {
  company: Company;
}

export default function CompanyCard({ company }: CompanyCardProps) {
  const id = company.short_name || company.name;

  return (
    <Link
      to={`/company/${encodeURIComponent(id)}`}
      className="surface-card p-4 hover:shadow-md transition-shadow group block"
    >
      <div className="flex items-start gap-3">
        {company.logo_url ? (
          <img
            src={company.logo_url.split(";")[0]?.trim()}
            alt={company.name}
            className="w-10 h-10 rounded-md object-contain bg-muted p-1 flex-shrink-0"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
        ) : (
          <div className="w-10 h-10 rounded-md bg-accent flex items-center justify-center flex-shrink-0">
            <Building2 size={20} className="text-primary" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors truncate">
            {company.name || "Unnamed Company"}
          </h3>
          {company.category && (
            <span className="chip mt-1 inline-block">{company.category}</span>
          )}
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-muted-foreground">
        {company.employee_size && (
          <div className="flex items-center gap-1">
            <Users size={12} />
            <span className="truncate">{company.employee_size}</span>
          </div>
        )}
        {company.focus_sectors && (
          <div className="flex items-center gap-1">
            <TrendingUp size={12} />
            <span className="truncate">{company.focus_sectors.split("|")[0]}</span>
          </div>
        )}
        {company.headquarters_address && (
          <div className="flex items-center gap-1 col-span-2">
            <MapPin size={12} />
            <span className="truncate">{company.headquarters_address}</span>
          </div>
        )}
      </div>

      {company.hiring_velocity && (
        <div className="mt-2">
          <span className="text-label">Hiring</span>
          <p className="text-xs text-foreground mt-0.5 truncate">
            {company.hiring_velocity.split("|")[0]}
          </p>
        </div>
      )}
    </Link>
  );
}
