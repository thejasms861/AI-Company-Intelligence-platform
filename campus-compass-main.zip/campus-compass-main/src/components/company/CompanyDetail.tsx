import { Company, CompanySection, companySections } from "@/types/company";
import {
  Building2,
  TrendingUp,
  Users,
  GraduationCap,
  Wallet,
  Shield,
  BarChart3,
  Cpu,
  UserCircle,
  Globe,
  ExternalLink,
} from "lucide-react";
import { useState } from "react";

const iconMap: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  Building2,
  TrendingUp,
  Users,
  GraduationCap,
  Wallet,
  Shield,
  BarChart3,
  Cpu,
  UserCircle,
  Globe,
};

function isUrl(value: string): boolean {
  return value.startsWith("http://") || value.startsWith("https://");
}

function FieldValue({ value }: { value: string }) {
  if (!value) return <span className="text-muted-foreground italic text-sm">—</span>;

  if (isUrl(value)) {
    return (
      <a
        href={value}
        target="_blank"
        rel="noopener noreferrer"
        className="text-primary hover:underline inline-flex items-center gap-1 text-sm"
      >
        {value.length > 50 ? value.slice(0, 50) + "…" : value}
        <ExternalLink size={12} />
      </a>
    );
  }

  // Handle pipe-separated values as chips
  if (value.includes("|")) {
    const parts = value.split("|").map((p) => p.trim()).filter(Boolean);
    return (
      <div className="flex flex-wrap gap-1.5">
        {parts.map((part, i) => (
          <span key={i} className="chip">
            {part}
          </span>
        ))}
      </div>
    );
  }

  return <p className="text-sm text-foreground leading-relaxed">{value}</p>;
}

function SectionPanel({
  section,
  company,
}: {
  section: CompanySection;
  company: Company;
}) {
  const Icon = iconMap[section.icon] || Building2;
  const hasData = section.fields.some((f) => company[f.key]);

  if (!hasData) return null;

  return (
    <div className="surface-card p-5">
      <div className="section-header mb-4">
        <Icon size={18} className="text-primary" />
        {section.title}
      </div>
      <div className="space-y-3">
        {section.fields.map((field) => {
          const value = company[field.key];
          if (!value) return null;
          return (
            <div key={field.key}>
              <span className="text-label">{field.label}</span>
              <div className="mt-1">
                <FieldValue value={String(value)} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function CompanyDetail({ company }: { company: Company }) {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-start gap-4 mb-6">
        {company.logo_url ? (
          <img
            src={company.logo_url.split(";")[0]?.trim()}
            alt={company.name}
            className="w-16 h-16 rounded-lg object-contain bg-muted p-2"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
        ) : (
          <div className="w-16 h-16 rounded-lg bg-accent flex items-center justify-center">
            <Building2 size={28} className="text-primary" />
          </div>
        )}
        <div>
          <h1 className="text-2xl font-semibold text-foreground">{company.name}</h1>
          {company.short_name && company.short_name !== company.name && (
            <p className="text-sm text-muted-foreground">{company.short_name}</p>
          )}
          <div className="flex flex-wrap gap-2 mt-2">
            {company.category && <span className="chip">{company.category}</span>}
            {company.profitability_status && (
              <span className="chip">{company.profitability_status}</span>
            )}
            {company.employee_size && (
              <span className="chip">{company.employee_size}</span>
            )}
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="border-b mb-6 overflow-x-auto">
        <div className="flex gap-0 min-w-max">
          {companySections.map((section, i) => {
            const Icon = iconMap[section.icon] || Building2;
            const hasData = section.fields.some((f) => company[f.key]);
            if (!hasData) return null;
            return (
              <button
                key={i}
                onClick={() => setActiveTab(i)}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === i
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon size={14} />
                <span className="hidden sm:inline">{section.title}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Section Content */}
      <div className="animate-fade-in">
        <SectionPanel section={companySections[activeTab]} company={company} />
      </div>
    </div>
  );
}
